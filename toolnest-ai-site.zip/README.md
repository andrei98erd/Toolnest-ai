# ToolNest AI

Mobile-first static website for an AI tools directory.

## Publish from a phone
1. Create a GitHub account.
2. Create a new public repository, e.g. `toolnest-ai`.
3. Upload all files in this folder.
4. Import the repository into a static host such as Vercel or Netlify.
5. Set your custom domain if you have one.
6. Replace `YOUR-DOMAIN.com` in `robots.txt` and `sitemap.xml`.
7. Before monetizing, replace the demo Privacy text with a real policy and add your actual analytics/ad provider code.

## Important
The advertisement boxes are placeholders. Do not click your own ads or encourage visitors to click ads. Add advertising only through the provider's approved integration and follow its policies.
