const tools=[
{name:"ChatGPT",cat:"Writing",icon:"C",desc:"General-purpose AI for writing, brainstorming, analysis and everyday tasks.",url:"https://chatgpt.com/"},
{name:"Claude",cat:"Writing",icon:"A",desc:"AI assistant useful for writing, analysis, documents and long-context work.",url:"https://claude.ai/"},
{name:"Canva",cat:"Images",icon:"Ca",desc:"Design platform with AI features for graphics, presentations and content.",url:"https://www.canva.com/"},
{name:"Midjourney",cat:"Images",icon:"M",desc:"AI image generation for creative concepts and visual exploration.",url:"https://www.midjourney.com/"},
{name:"Runway",cat:"Video",icon:"R",desc:"AI-powered tools for generating and editing video and visual content.",url:"https://runwayml.com/"},
{name:"GitHub Copilot",cat:"Coding",icon:"G",desc:"AI coding assistance for developers working in supported environments.",url:"https://github.com/features/copilot"},
{name:"Perplexity",cat:"Research",icon:"P",desc:"AI search and research assistant designed to help explore questions.",url:"https://www.perplexity.ai/"},
{name:"Notion",cat:"Productivity",icon:"N",desc:"Workspace for notes, projects and knowledge management with AI features.",url:"https://www.notion.so/"},
{name:"Grammarly",cat:"Writing",icon:"Gr",desc:"Writing assistant for clarity, tone, grammar and communication.",url:"https://www.grammarly.com/"}
];
const grid=document.getElementById("toolGrid"), count=document.getElementById("resultCount");
function render(list){grid.innerHTML=list.map(t=>`<article class="tool"><div class="tool-top"><div class="logo">${t.icon}</div><div><h3>${t.name}</h3><span class="tag">${t.cat}</span></div></div><p>${t.desc}</p><a href="${t.url}" target="_blank" rel="noopener noreferrer sponsored">Visit website →</a></article>`).join("");count.textContent=`${list.length} tools`; }
function filterTools(){const q=document.getElementById("toolSearch").value.toLowerCase(),c=document.getElementById("categoryFilter").value;render(tools.filter(t=>(c==="all"||t.cat===c)&&(t.name.toLowerCase().includes(q)||t.desc.toLowerCase().includes(q)||t.cat.toLowerCase().includes(q))));}
function searchTools(){document.getElementById("toolSearch").value=document.getElementById("heroSearch").value;document.getElementById("tools").scrollIntoView();filterTools();}
document.getElementById("themeToggle").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("dark",document.body.classList.contains("dark"));};
if(localStorage.getItem("dark")==="true")document.body.classList.add("dark");
document.querySelector(".menu-btn").onclick=()=>document.querySelector(".nav").classList.toggle("open");
function subscribe(e){e.preventDefault();document.getElementById("formMsg").textContent="Thanks! Connect this form to your email provider before launch.";e.target.reset();}
render(tools);
